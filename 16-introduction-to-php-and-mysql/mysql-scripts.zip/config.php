<?php
	$dbhost = "localhost";
	$dbuser = "dbtest";
	$dbpass = "coffee";
	$dbname = "dbtest";
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>