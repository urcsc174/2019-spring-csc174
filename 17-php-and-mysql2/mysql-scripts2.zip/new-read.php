<?php
	// 1. Create a database connection
	require_once("config.php");

	// 2. Perform database query
	$query  = "SELECT * FROM test";
	$result = mysqli_query($connection, $query);
?>
<!doctype html>
<html>
<head>
	<title>Database Read</title>
</head>
<body>

	<h1>Database Read</h1>

	<ul>
	<?php
		// 3. Use returned data (if any)
		while($data = mysqli_fetch_assoc($result)) {
	?>
		<li><?php echo $data["firstName"], " ", $data["lastName"], "<br><strong>", $data["email"], "</strong>"; ?></li>
	<?php } ?>
</ul>

<!-- reset the database pointer -->
<?php mysqli_data_seek($result,0); ?>

<table border>
  <tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
  </tr>
<?php
// loop through results of database query, displaying them in the table
while($row = mysqli_fetch_array( $result )) {
?>
  <tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['firstName']; ?></td>
    <td><?php echo $row['lastName']; ?></td>
    <td><?php echo $row['email']; ?></td>
  </tr>
<?php
// close the loop
}
?>
</table>


<div>
	<a href=".">Go back to the Index</a>
</div>

</body>
</html>

<?php
	// 4. Release returned data
	mysqli_free_result($result);

	// 5. Close database connection
	mysqli_close($connection);
?>