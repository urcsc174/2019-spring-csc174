CREATE TABLE `test` (
`id` int(11) NOT NULL auto_increment,
`firstName` varchar(32) NOT NULL,
`lastName` varchar(32) NOT NULL,
`email` varchar(32) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;